import { Check } from "lucide-react";
import { PLANS } from "../config/plans";
import { useLanguage } from "../contexts/LanguageContext";
import { useMembership } from "../contexts/MembershipContext";

export function PlanCards() {
  const { t } = useLanguage();
  const { membershipLevel } = useMembership();

  const tierOrder = ["free", "basic", "premium", "vip"];
  const userTierIdx = tierOrder.indexOf(membershipLevel);

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <h2 className="text-3xl font-display font-bold text-foreground mb-8 text-center">
        {t("plans_title")}
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {PLANS.map((plan, idx) => {
          const isActive = membershipLevel === plan.id;
          const planTierIdx = tierOrder.indexOf(plan.id);
          const isOwned =
            userTierIdx >= planTierIdx && membershipLevel !== "free";

          return (
            <div
              key={plan.id}
              className={`relative flex flex-col rounded-2xl border-2 bg-card p-6 ${plan.borderClass} transition-transform hover:scale-[1.01]`}
              data-ocid={`plans.card.${idx + 1}`}
            >
              {isOwned && (
                <div className="absolute top-4 right-4 flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full bg-success/20 text-success">
                  <Check size={11} />
                  Active
                </div>
              )}

              {/* Plan label */}
              <div className="mb-5">
                <span
                  className="text-xs font-bold tracking-widest uppercase px-3 py-1 rounded-full"
                  style={{
                    color: plan.labelColor,
                    backgroundColor: `${plan.labelColor}22`,
                  }}
                >
                  {plan.label}
                </span>
              </div>

              {/* Conditions */}
              <div className="flex-1 space-y-3">
                <div className="flex items-center gap-2 text-foreground">
                  <span className="text-2xl font-bold">{plan.usdPrice}</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span style={{ color: plan.labelColor }}>◆</span>
                    <span>or {plan.coinXAmount}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span style={{ color: plan.labelColor }}>◆</span>
                    <span>or {plan.nftType}</span>
                  </div>
                </div>
              </div>

              {isActive && (
                <div
                  className="mt-4 text-center text-xs font-medium"
                  style={{ color: plan.labelColor }}
                >
                  ✓ Your current plan
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}

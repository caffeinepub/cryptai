import { TICKER_DATA } from "../config/ticker";

function TickerItem({
  symbol,
  price,
  change,
}: { symbol: string; price: number; change: number }) {
  const isPositive = change >= 0;
  const formatted =
    price >= 1000
      ? `$${price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
      : price >= 1
        ? `$${price.toFixed(2)}`
        : `$${price.toFixed(4)}`;

  return (
    <span className="inline-flex items-center gap-2 px-4 whitespace-nowrap">
      <span className="font-semibold text-foreground text-sm">{symbol}</span>
      <span className="text-muted-foreground text-sm">{formatted}</span>
      <span
        className={`text-xs font-medium px-1.5 py-0.5 rounded ${
          isPositive
            ? "text-green-400 bg-green-400/10"
            : "text-red-400 bg-red-400/10"
        }`}
      >
        {isPositive ? "+" : ""}
        {change}%
      </span>
      <span className="text-border mx-2">•</span>
    </span>
  );
}

export function MarketTicker() {
  const items = [...TICKER_DATA, ...TICKER_DATA]; // duplicate for seamless loop

  return (
    <div className="w-full overflow-hidden border-b border-border bg-[oklch(0.11_0.006_245)] dark:bg-[oklch(0.095_0.006_245)]">
      <div className="flex ticker-scroll py-2.5">
        {items.map((item, idx) => (
          <TickerItem key={`${item.symbol}-${idx}`} {...item} />
        ))}
      </div>
    </div>
  );
}

export interface TickerItem {
  symbol: string;
  price: number;
  change: number;
}

export const TICKER_DATA: TickerItem[] = [
  { symbol: "BTC", price: 67234.5, change: 2.3 },
  { symbol: "ETH", price: 3512.8, change: 1.8 },
  { symbol: "SOL", price: 172.4, change: 4.2 },
  { symbol: "BNB", price: 412.2, change: -0.5 },
  { symbol: "ADA", price: 0.52, change: 1.1 },
  { symbol: "DOGE", price: 0.18, change: -1.3 },
  { symbol: "MATIC", price: 0.89, change: 2.7 },
  { symbol: "LINK", price: 18.3, change: 3.1 },
  { symbol: "DOT", price: 9.15, change: -0.8 },
  { symbol: "AVAX", price: 38.9, change: 1.5 },
];

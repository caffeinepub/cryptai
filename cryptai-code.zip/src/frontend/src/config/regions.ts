export const ARABIC_COUNTRY_CODES = [
  "SA",
  "AE",
  "EG",
  "MA",
  "DZ",
  "TN",
  "LY",
  "IQ",
  "SY",
  "JO",
  "LB",
  "KW",
  "QA",
  "BH",
  "OM",
  "YE",
  "SD",
  "PS",
];

export const COUNTRY_LANGUAGE_MAP: Record<string, string> = {
  DE: "de",
  FR: "fr",
  ES: "es",
  IT: "it",
  PT: "pt",
  NL: "nl",
  PL: "pl",
  RU: "ru",
  JP: "ja",
  CN: "zh",
  KR: "ko",
  TR: "tr",
  SE: "sv",
  NO: "no",
  DK: "da",
  FI: "fi",
  GR: "el",
  CZ: "cs",
  HU: "hu",
  RO: "ro",
};

export const LANGUAGE_LABELS: Record<string, string> = {
  en: "English",
  de: "Deutsch",
  fr: "Français",
  es: "Español",
  it: "Italiano",
  pt: "Português",
  ar: "العربية",
  nl: "Nederlands",
  pl: "Polski",
  ru: "Русский",
  ja: "日本語",
  zh: "中文",
  ko: "한국어",
  tr: "Türkçe",
  sv: "Svenska",
};

export type Language = "en" | "de" | "fr" | "ar" | string;

export type TranslationKey =
  | "nav_home"
  | "nav_ai"
  | "nav_crypto"
  | "connect_wallet"
  | "disconnect"
  | "wallet_disclaimer"
  | "dark_mode"
  | "light_mode"
  | "subscribe"
  | "newsletter_title"
  | "newsletter_hint"
  | "email_placeholder"
  | "subscribe_success"
  | "subscribe_error"
  | "plans_title"
  | "articles_title"
  | "footer_tagline"
  | "ai_desc"
  | "crypto_desc"
  | "upgrade_to"
  | "locked_content"
  | "paypal_btn"
  | "coinx_btn"
  | "nft_btn"
  | "login"
  | "register"
  | "logout"
  | "username"
  | "password"
  | "confirm_password"
  | "account_settings"
  | "change_password"
  | "old_password"
  | "new_password"
  | "passwords_dont_match"
  | "username_taken"
  | "invalid_credentials"
  | "register_to_read"
  | "register_prompt_title"
  | "register_prompt_desc"
  | "minutes_left"
  | "payment_title"
  | "payment_card_desc"
  | "payment_coinx_desc"
  | "payment_nft_desc"
  | "login_register";

export const TRANSLATIONS: Record<string, Record<TranslationKey, string>> = {
  en: {
    nav_home: "Home",
    nav_ai: "AI",
    nav_crypto: "Crypto & Market",
    connect_wallet: "Connect Wallet",
    disconnect: "Disconnect",
    wallet_disclaimer:
      "This website does not execute any wallet transactions. It only checks whether the required amount of CoinX or the required NFTs are present in the wallet.",
    dark_mode: "Dark Mode",
    light_mode: "Light Mode",
    subscribe: "Subscribe",
    newsletter_title: "Stay Updated",
    newsletter_hint: "Receive updates on AI, Crypto & Market.",
    email_placeholder: "Your email address",
    subscribe_success: "Successfully subscribed!",
    subscribe_error: "Subscription failed. Please try again.",
    plans_title: "Choose Your Plan",
    articles_title: "Latest Insights",
    footer_tagline: "Your gateway to AI & Crypto intelligence.",
    ai_desc:
      "Explore the latest in artificial intelligence, machine learning, and emerging AI technologies.",
    crypto_desc:
      "Real-time market data, crypto analysis, and blockchain insights.",
    upgrade_to: "Upgrade to",
    locked_content: "This content requires a higher membership tier.",
    paypal_btn: "PayPal / Visa / MC",
    coinx_btn: "Buy CoinX",
    nft_btn: "Buy NFT",
    login: "Login",
    register: "Register",
    logout: "Logout",
    username: "Username",
    password: "Password",
    confirm_password: "Confirm Password",
    account_settings: "Account Settings",
    change_password: "Change Password",
    old_password: "Old Password",
    new_password: "New Password",
    passwords_dont_match: "Passwords do not match",
    username_taken: "Username already taken",
    invalid_credentials: "Invalid username or password",
    register_to_read: "Register to continue reading",
    register_prompt_title: "Your free reading time has ended",
    register_prompt_desc:
      "Create a free account to keep reading. Registered users get full access to all free content plus one Basic article.",
    minutes_left: "min left",
    payment_title: "How to Purchase",
    payment_card_desc: "Pay with PayPal, Visa, or Mastercard",
    payment_coinx_desc: "Use your CoinX token balance",
    payment_nft_desc: "Own a qualifying NFT for access",
    login_register: "Login / Register",
  },
  de: {
    nav_home: "Startseite",
    nav_ai: "KI",
    nav_crypto: "Krypto & Markt",
    connect_wallet: "Wallet verbinden",
    disconnect: "Trennen",
    wallet_disclaimer:
      "Diese Webseite führt keine Wallet-Transaktionen aus. Es wird ausschließlich geprüft, ob die erforderliche Anzahl an CoinX oder die erforderlichen NFTs in der Wallet vorhanden sind.",
    dark_mode: "Dunkelmodus",
    light_mode: "Hellmodus",
    subscribe: "Abonnieren",
    newsletter_title: "Bleib informiert",
    newsletter_hint: "Erhalte Updates zu KI, Krypto & Markt.",
    email_placeholder: "Deine E-Mail-Adresse",
    subscribe_success: "Erfolgreich abonniert!",
    subscribe_error: "Abonnement fehlgeschlagen. Bitte erneut versuchen.",
    plans_title: "Wähle deinen Plan",
    articles_title: "Neueste Einblicke",
    footer_tagline: "Dein Tor zu KI & Krypto-Wissen.",
    ai_desc:
      "Entdecke die neuesten Entwicklungen in künstlicher Intelligenz und maschinellem Lernen.",
    crypto_desc:
      "Echtzeit-Marktdaten, Krypto-Analysen und Blockchain-Einblicke.",
    upgrade_to: "Upgrade auf",
    locked_content: "Dieser Inhalt erfordert eine höhere Mitgliedschaftsstufe.",
    paypal_btn: "PayPal / Visa / MC",
    coinx_btn: "CoinX kaufen",
    nft_btn: "NFT kaufen",
    login: "Anmelden",
    register: "Registrieren",
    logout: "Abmelden",
    username: "Benutzername",
    password: "Passwort",
    confirm_password: "Passwort bestätigen",
    account_settings: "Kontoeinstellungen",
    change_password: "Passwort ändern",
    old_password: "Altes Passwort",
    new_password: "Neues Passwort",
    passwords_dont_match: "Passwörter stimmen nicht überein",
    username_taken: "Benutzername bereits vergeben",
    invalid_credentials: "Ungültiger Benutzername oder Passwort",
    register_to_read: "Registrieren um weiterzulesen",
    register_prompt_title: "Deine kostenlose Lesezeit ist abgelaufen",
    register_prompt_desc:
      "Erstelle ein kostenloses Konto um weiterzulesen. Registrierte Nutzer erhalten Zugang zu allen kostenlosen Inhalten plus einem Basic-Artikel.",
    minutes_left: "Min übrig",
    payment_title: "Wie kaufen?",
    payment_card_desc: "Mit PayPal, Visa oder Mastercard bezahlen",
    payment_coinx_desc: "CoinX-Token-Guthaben verwenden",
    payment_nft_desc: "Qualifizierendes NFT für Zugang besitzen",
    login_register: "Anmelden / Registrieren",
  },
  fr: {
    nav_home: "Accueil",
    nav_ai: "IA",
    nav_crypto: "Crypto & Marché",
    connect_wallet: "Connecter Wallet",
    disconnect: "Déconnecter",
    wallet_disclaimer:
      "Ce site n'effectue aucune transaction de portefeuille. Il vérifie uniquement si la quantité requise de CoinX ou les NFT requis sont présents dans le portefeuille.",
    dark_mode: "Mode sombre",
    light_mode: "Mode clair",
    subscribe: "S'abonner",
    newsletter_title: "Restez informé",
    newsletter_hint:
      "Recevez des mises à jour sur l'IA, la Crypto & le Marché.",
    email_placeholder: "Votre adresse e-mail",
    subscribe_success: "Abonnement réussi!",
    subscribe_error: "Échec de l'abonnement. Veuillez réessayer.",
    plans_title: "Choisissez votre plan",
    articles_title: "Dernières analyses",
    footer_tagline: "Votre passerelle vers l'intelligence IA & Crypto.",
    ai_desc:
      "Explorez les dernières avancées en intelligence artificielle et apprentissage automatique.",
    crypto_desc:
      "Données de marché en temps réel, analyses crypto et insights blockchain.",
    upgrade_to: "Passer à",
    locked_content: "Ce contenu nécessite un niveau d'adhésion supérieur.",
    paypal_btn: "PayPal / Visa / MC",
    coinx_btn: "Acheter CoinX",
    nft_btn: "Acheter NFT",
    login: "Connexion",
    register: "S'inscrire",
    logout: "Déconnexion",
    username: "Nom d'utilisateur",
    password: "Mot de passe",
    confirm_password: "Confirmer le mot de passe",
    account_settings: "Paramètres du compte",
    change_password: "Changer le mot de passe",
    old_password: "Ancien mot de passe",
    new_password: "Nouveau mot de passe",
    passwords_dont_match: "Les mots de passe ne correspondent pas",
    username_taken: "Nom d'utilisateur déjà pris",
    invalid_credentials: "Nom d'utilisateur ou mot de passe invalide",
    register_to_read: "Inscrivez-vous pour continuer à lire",
    register_prompt_title: "Votre temps de lecture gratuit est écoulé",
    register_prompt_desc:
      "Créez un compte gratuit pour continuer à lire. Les utilisateurs inscrits ont accès à tout le contenu gratuit plus un article Basic.",
    minutes_left: "min restantes",
    payment_title: "Comment acheter",
    payment_card_desc: "Payez avec PayPal, Visa ou Mastercard",
    payment_coinx_desc: "Utilisez votre solde de tokens CoinX",
    payment_nft_desc: "Possédez un NFT qualifiant pour l'accès",
    login_register: "Connexion / Inscription",
  },
  ar: {
    nav_home: "الرئيسية",
    nav_ai: "الذكاء الاصطناعي",
    nav_crypto: "العملات والسوق",
    connect_wallet: "ربط المحفظة",
    disconnect: "قطع الاتصال",
    wallet_disclaimer:
      "هذا الموقع لا ينفذ أي معاملات للمحفظة. يتحقق فقط من وجود الكمية المطلوبة من CoinX أو NFT المطلوبة في المحفظة.",
    dark_mode: "الوضع الداكن",
    light_mode: "الوضع الفاتح",
    subscribe: "اشتراك",
    newsletter_title: "ابق على اطلاع",
    newsletter_hint: "احصل على تحديثات حول الذكاء الاصطناعي والعملات المشفرة.",
    email_placeholder: "عنوان بريدك الإلكتروني",
    subscribe_success: "تم الاشتراك بنجاح!",
    subscribe_error: "فشل الاشتراك. يرجى المحاولة مرة أخرى.",
    plans_title: "اختر خطتك",
    articles_title: "أحدث المقالات",
    footer_tagline: "بوابتك لذكاء الذكاء الاصطناعي والعملات المشفرة.",
    ai_desc: "استكشف أحدث التطورات في الذكاء الاصطناعي والتعلم الآلي.",
    crypto_desc: "بيانات السوق في الوقت الفعلي وتحليلات العملات المشفرة.",
    upgrade_to: "ترقية إلى",
    locked_content: "هذا المحتوى يتطلب مستوى عضوية أعلى.",
    paypal_btn: "PayPal / Visa / MC",
    coinx_btn: "شراء CoinX",
    nft_btn: "شراء NFT",
    login: "تسجيل الدخول",
    register: "تسجيل",
    logout: "تسجيل الخروج",
    username: "اسم المستخدم",
    password: "كلمة المرور",
    confirm_password: "تأكيد كلمة المرور",
    account_settings: "إعدادات الحساب",
    change_password: "تغيير كلمة المرور",
    old_password: "كلمة المرور القديمة",
    new_password: "كلمة المرور الجديدة",
    passwords_dont_match: "كلمات المرور غير متطابقة",
    username_taken: "اسم المستخدم مأخوذ بالفعل",
    invalid_credentials: "اسم المستخدم أو كلمة المرور غير صحيحة",
    register_to_read: "سجل للاستمرار في القراءة",
    register_prompt_title: "انتهى وقت القراءة المجاني",
    register_prompt_desc:
      "أنشئ حسابًا مجانيًا للاستمرار في القراءة. يحصل المستخدمون المسجلون على الوصول الكامل للمحتوى المجاني بالإضافة إلى مقالة أساسية واحدة.",
    minutes_left: "دقائق متبقية",
    payment_title: "كيفية الشراء",
    payment_card_desc: "ادفع باستخدام PayPal أو Visa أو Mastercard",
    payment_coinx_desc: "استخدم رصيد رمز CoinX الخاص بك",
    payment_nft_desc: "امتلك NFT مؤهلًا للوصول",
    login_register: "تسجيل الدخول / التسجيل",
  },
};

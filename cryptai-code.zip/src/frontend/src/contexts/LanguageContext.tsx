import { createContext, useContext, useState } from "react";
import {
  ARABIC_COUNTRY_CODES,
  COUNTRY_LANGUAGE_MAP,
  LANGUAGE_LABELS,
  type Language,
  TRANSLATIONS,
  type TranslationKey,
} from "../config/regions";

function detectRegion(): {
  countryCode: string;
  isArabic: boolean;
  localLang: string;
} {
  const locale = navigator.language || "en-US";
  const parts = locale.split("-");
  const lang = parts[0].toLowerCase();
  const country = (parts[1] || "").toUpperCase();

  const isArabic = lang === "ar" || ARABIC_COUNTRY_CODES.includes(country);
  const localLang = COUNTRY_LANGUAGE_MAP[country] || lang || "en";

  return { countryCode: country, isArabic, localLang };
}

interface LanguageContextValue {
  currentLanguage: Language;
  availableLanguages: { code: string; label: string }[];
  isArabicRegion: boolean;
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKey) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextValue>({
  currentLanguage: "en",
  availableLanguages: [{ code: "en", label: "English" }],
  isArabicRegion: false,
  setLanguage: () => {},
  t: (key) => key,
  isRTL: false,
});

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const { isArabic, localLang } = detectRegion();

  const enLabel = LANGUAGE_LABELS.en;
  const frLabel = LANGUAGE_LABELS.fr;
  const arLabel = LANGUAGE_LABELS.ar;
  const localLabel = LANGUAGE_LABELS[localLang];

  const availableLanguages = isArabic
    ? [
        { code: "en", label: enLabel },
        { code: "fr", label: frLabel },
        { code: "ar", label: arLabel },
      ]
    : [
        { code: "en", label: enLabel },
        ...(localLang !== "en" && localLabel
          ? [{ code: localLang, label: localLabel }]
          : []),
      ];

  const [currentLanguage, setCurrentLanguage] = useState<Language>(
    localStorage.getItem("cryptai-lang") || availableLanguages[0].code,
  );

  const setLanguage = (lang: Language) => {
    setCurrentLanguage(lang);
    localStorage.setItem("cryptai-lang", lang);
  };

  const t = (key: TranslationKey): string => {
    const translations = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;
    return translations[key] || TRANSLATIONS.en[key] || key;
  };

  const isRTL = currentLanguage === "ar";

  return (
    <LanguageContext.Provider
      value={{
        currentLanguage,
        availableLanguages,
        isArabicRegion: isArabic,
        setLanguage,
        t,
        isRTL,
      }}
    >
      <div dir={isRTL ? "rtl" : "ltr"}>{children}</div>
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}

import { useLanguage } from "../contexts/LanguageContext";

const METHODS = [
  {
    icon: "💳",
    titleKey: "paypal_btn" as const,
    descKey: "payment_card_desc" as const,
    ocid: "payment.card.button",
    href: "https://paypal.com",
  },
  {
    icon: "🪙",
    titleKey: "coinx_btn" as const,
    descKey: "payment_coinx_desc" as const,
    ocid: "payment.coinx.button",
    href: "https://coinmarketcap.com",
  },
  {
    icon: "🖼️",
    titleKey: "nft_btn" as const,
    descKey: "payment_nft_desc" as const,
    ocid: "payment.nft.button",
    href: "https://opensea.io",
  },
];

export function PaymentMethods() {
  const { t } = useLanguage();

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      <h2 className="text-2xl font-display font-bold text-foreground mb-6 text-center">
        {t("payment_title")}
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {METHODS.map((method) => (
          <a
            key={method.ocid}
            href={method.href}
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center gap-3 rounded-2xl border border-border bg-card p-6 text-center hover:border-primary/40 transition-colors group"
            data-ocid={method.ocid}
          >
            <span className="text-4xl">{method.icon}</span>
            <span className="font-semibold text-foreground group-hover:text-primary transition-colors">
              {t(method.titleKey)}
            </span>
            <span className="text-sm text-muted-foreground">
              {t(method.descKey)}
            </span>
          </a>
        ))}
      </div>
    </section>
  );
}

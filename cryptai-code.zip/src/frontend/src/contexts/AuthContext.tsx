import { createContext, useContext, useEffect, useState } from "react";

interface StoredUser {
  username: string;
  passwordHash: string;
  preferredLanguage?: string;
}

interface CurrentUser {
  username: string;
  preferredLanguage?: string;
}

interface AuthContextValue {
  currentUser: CurrentUser | null;
  register: (
    username: string,
    password: string,
  ) => { success: boolean; error?: string };
  login: (
    username: string,
    password: string,
  ) => { success: boolean; error?: string };
  logout: () => void;
  updatePreferredLanguage: (lang: string) => void;
  updatePassword: (
    oldPassword: string,
    newPassword: string,
  ) => { success: boolean; error?: string };
  isLoggedIn: boolean;
}

const AuthContext = createContext<AuthContextValue>({
  currentUser: null,
  register: () => ({ success: false }),
  login: () => ({ success: false }),
  logout: () => {},
  updatePreferredLanguage: () => {},
  updatePassword: () => ({ success: false }),
  isLoggedIn: false,
});

const USERS_KEY = "cryptai-users";
const SESSION_KEY = "cryptai-session";

function getUsers(): StoredUser[] {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveUsers(users: StoredUser[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function hashPassword(password: string): string {
  return btoa(password);
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(() => {
    try {
      const session = localStorage.getItem(SESSION_KEY);
      return session ? JSON.parse(session) : null;
    } catch {
      return null;
    }
  });

  // Sync session to localStorage when currentUser changes
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(SESSION_KEY);
    }
  }, [currentUser]);

  const register = (
    username: string,
    password: string,
  ): { success: boolean; error?: string } => {
    const users = getUsers();
    if (
      users.find((u) => u.username.toLowerCase() === username.toLowerCase())
    ) {
      return { success: false, error: "username_taken" };
    }
    const newUser: StoredUser = {
      username,
      passwordHash: hashPassword(password),
    };
    saveUsers([...users, newUser]);
    setCurrentUser({ username });
    return { success: true };
  };

  const login = (
    username: string,
    password: string,
  ): { success: boolean; error?: string } => {
    const users = getUsers();
    const user = users.find(
      (u) => u.username.toLowerCase() === username.toLowerCase(),
    );
    if (!user || user.passwordHash !== hashPassword(password)) {
      return { success: false, error: "invalid_credentials" };
    }
    setCurrentUser({
      username: user.username,
      preferredLanguage: user.preferredLanguage,
    });
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const updatePreferredLanguage = (lang: string) => {
    if (!currentUser) return;
    const users = getUsers();
    const idx = users.findIndex((u) => u.username === currentUser.username);
    if (idx !== -1) {
      users[idx].preferredLanguage = lang;
      saveUsers(users);
    }
    setCurrentUser((prev) =>
      prev ? { ...prev, preferredLanguage: lang } : prev,
    );
  };

  const updatePassword = (
    oldPassword: string,
    newPassword: string,
  ): { success: boolean; error?: string } => {
    if (!currentUser) return { success: false, error: "invalid_credentials" };
    const users = getUsers();
    const idx = users.findIndex((u) => u.username === currentUser.username);
    if (idx === -1 || users[idx].passwordHash !== hashPassword(oldPassword)) {
      return { success: false, error: "invalid_credentials" };
    }
    users[idx].passwordHash = hashPassword(newPassword);
    saveUsers(users);
    return { success: true };
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        register,
        login,
        logout,
        updatePreferredLanguage,
        updatePassword,
        isLoggedIn: !!currentUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

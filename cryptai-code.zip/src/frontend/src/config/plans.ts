export interface PlanConfig {
  id: "basic" | "premium" | "vip";
  label: string;
  usdPrice: string;
  coinXAmount: string;
  nftType: string;
  purchaseLinks: {
    paypal: string;
    coinX: string;
    nft: string;
  };
  borderClass: string;
  labelColor: string;
}

export const PLANS: PlanConfig[] = [
  {
    id: "basic",
    label: "BASIC",
    usdPrice: "$5 USD",
    coinXAmount: "500 CoinX",
    nftType: "NFT Basic",
    purchaseLinks: { paypal: "#", coinX: "#", nft: "#" },
    borderClass: "plan-copper",
    labelColor: "#B87333",
  },
  {
    id: "premium",
    label: "PREMIUM",
    usdPrice: "$XX USD",
    coinXAmount: "XXXX CoinX",
    nftType: "NFT Premium",
    purchaseLinks: { paypal: "#", coinX: "#", nft: "#" },
    borderClass: "plan-silver",
    labelColor: "#9CA3AF",
  },
  {
    id: "vip",
    label: "VIP",
    usdPrice: "$XX USD",
    coinXAmount: "XXXX CoinX",
    nftType: "NFT VIP",
    purchaseLinks: { paypal: "#", coinX: "#", nft: "#" },
    borderClass: "plan-gold",
    labelColor: "#D4AF37",
  },
];

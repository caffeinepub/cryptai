import { Music } from "lucide-react";
import {
  SiDiscord,
  SiGithub,
  SiReddit,
  SiTelegram,
  SiX,
  SiYoutube,
} from "react-icons/si";

export function Footer() {
  const year = new Date().getFullYear();
  const hostname = encodeURIComponent(window.location.hostname);

  const socialLinks = [
    { icon: SiX, label: "X (Twitter)", href: "https://x.com" },
    { icon: SiDiscord, label: "Discord", href: "https://discord.com" },
    { icon: SiTelegram, label: "Telegram", href: "https://t.me" },
    { icon: SiReddit, label: "Reddit", href: "https://reddit.com" },
    { icon: SiYoutube, label: "YouTube", href: "https://youtube.com" },
    { icon: SiGithub, label: "GitHub", href: "https://github.com" },
  ];

  return (
    <footer className="border-t border-border bg-card mt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="font-display font-bold text-xl mb-2">
              <span className="text-foreground">Crypt</span>
              <span className="text-primary">AI</span>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Your gateway to AI & Crypto intelligence.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold text-foreground mb-4 text-sm uppercase tracking-wider">
              Legal
            </h4>
            <ul className="space-y-2">
              {[
                { label: "Impressum", href: "/" },
                { label: "Datenschutz", href: "/" },
                { label: "Terms", href: "/" },
                { label: "Kontakt", href: "/" },
              ].map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    data-ocid={`footer.${link.label.toLowerCase()}.link`}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="font-semibold text-foreground mb-4 text-sm uppercase tracking-wider">
              Community
            </h4>
            <div className="flex flex-wrap gap-2">
              {socialLinks.map(({ icon: Icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-background text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors"
                  data-ocid={`footer.${label.toLowerCase().replace(/[^a-z0-9]/g, "")}.link`}
                >
                  <Icon size={16} />
                </a>
              ))}
              {/* Suno */}
              <a
                href="https://suno.com"
                aria-label="Suno"
                title="Suno"
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 items-center justify-center gap-1 rounded-lg border border-border bg-background px-2.5 text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors text-xs font-medium"
                data-ocid="footer.suno.link"
              >
                <Music size={14} />
                Suno
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-border pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-muted-foreground">
          <span>© {year} CryptAI. All rights reserved.</span>
          <a
            href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${hostname}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-foreground transition-colors"
          >
            Built with ❤️ using caffeine.ai
          </a>
        </div>
      </div>
    </footer>
  );
}

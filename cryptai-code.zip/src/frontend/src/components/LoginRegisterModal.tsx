import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";

interface LoginRegisterModalProps {
  open: boolean;
  onClose: () => void;
  defaultTab?: "login" | "register";
}

export function LoginRegisterModal({
  open,
  onClose,
  defaultTab = "login",
}: LoginRegisterModalProps) {
  const { login, register } = useAuth();
  const { t } = useLanguage();

  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  const [regUsername, setRegUsername] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regConfirm, setRegConfirm] = useState("");
  const [regError, setRegError] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    const result = login(loginUsername.trim(), loginPassword);
    if (result.success) {
      onClose();
    } else {
      setLoginError(t((result.error as any) || "invalid_credentials"));
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError("");
    if (regPassword !== regConfirm) {
      setRegError(t("passwords_dont_match"));
      return;
    }
    const result = register(regUsername.trim(), regPassword);
    if (result.success) {
      onClose();
    } else {
      setRegError(t((result.error as any) || "username_taken"));
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        className="sm:max-w-md bg-card border-border"
        data-ocid="auth.modal"
      >
        <DialogHeader>
          <DialogTitle className="text-foreground">
            {t("login_register")}
          </DialogTitle>
        </DialogHeader>
        <Tabs defaultValue={defaultTab} className="mt-2">
          <TabsList className="grid w-full grid-cols-2 bg-muted">
            <TabsTrigger value="login" data-ocid="auth.login.tab">
              {t("login")}
            </TabsTrigger>
            <TabsTrigger value="register" data-ocid="auth.register.tab">
              {t("register")}
            </TabsTrigger>
          </TabsList>

          {/* Login */}
          <TabsContent value="login">
            <form onSubmit={handleLogin} className="space-y-4 pt-4">
              <div className="space-y-1.5">
                <Label htmlFor="login-user">{t("username")}</Label>
                <Input
                  id="login-user"
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                  required
                  autoComplete="username"
                  data-ocid="auth.login.input"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="login-pass">{t("password")}</Label>
                <Input
                  id="login-pass"
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  required
                  autoComplete="current-password"
                  data-ocid="auth.login_password.input"
                />
              </div>
              {loginError && (
                <p
                  className="text-sm text-destructive"
                  data-ocid="auth.login.error_state"
                >
                  {loginError}
                </p>
              )}
              <Button
                type="submit"
                className="w-full rounded-full"
                data-ocid="auth.login.submit_button"
              >
                {t("login")}
              </Button>
            </form>
          </TabsContent>

          {/* Register */}
          <TabsContent value="register">
            <form onSubmit={handleRegister} className="space-y-4 pt-4">
              <div className="space-y-1.5">
                <Label htmlFor="reg-user">{t("username")}</Label>
                <Input
                  id="reg-user"
                  value={regUsername}
                  onChange={(e) => setRegUsername(e.target.value)}
                  required
                  autoComplete="username"
                  data-ocid="auth.register.input"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="reg-pass">{t("password")}</Label>
                <Input
                  id="reg-pass"
                  type="password"
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  required
                  autoComplete="new-password"
                  data-ocid="auth.register_password.input"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="reg-confirm">{t("confirm_password")}</Label>
                <Input
                  id="reg-confirm"
                  type="password"
                  value={regConfirm}
                  onChange={(e) => setRegConfirm(e.target.value)}
                  required
                  autoComplete="new-password"
                  data-ocid="auth.register_confirm.input"
                />
              </div>
              {regError && (
                <p
                  className="text-sm text-destructive"
                  data-ocid="auth.register.error_state"
                >
                  {regError}
                </p>
              )}
              <Button
                type="submit"
                className="w-full rounded-full"
                data-ocid="auth.register.submit_button"
              >
                {t("register")}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
